#include<iostream>
using namespace std;
int main(){
    for(int i=0;i<10;i++){
        if(i<4){
                for(int j=4-i; j>0; j--){
                    cout<<"  ";
                }
            for(int x=0; x<(2*i)+1; x++){
                cout<<" *";
            }
            cout<<endl;
        }
        else if(i>4 && i<11){
            for(int y=0; y<9; y++){
                cout<<" *";
            }
            cout<<endl;
        }
    }
    
    return 0;
}