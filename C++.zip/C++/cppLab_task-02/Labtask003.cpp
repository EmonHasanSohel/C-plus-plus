#include<iostream>
using namespace std;
int main(){
    int num;
    cout<<"Enter the Fibonacci numbers to Generat:";
    cin>>num;
    if(num<=0){
        cout<<"Enter a Positive number:"<<endl;
        return 0;
    }
    int first=0, second=1;
    cout<<"First "<<num<<" Fibonacci Numbers:";
    if(num>=1){
        cout<<first<<" ";


    }
    if(num>=2){
        cout<<second<<" ";


    }
    for (int i=3;i<=num;++i){
        int next=first+second;
        cout<<next<<" ";
        first=second;
        second=next;

    }
    cout<<endl;
}