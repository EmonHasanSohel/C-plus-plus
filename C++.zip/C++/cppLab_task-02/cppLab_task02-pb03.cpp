#include<iostream>
using namespace std;
int main(){
    int a=0, b=1,sum,num;
    cout<<"Enter a number:";
    cin>>num;
    for(int i=0; i<num; i++){
        if(i<=1){
            cout<<i<<" ";
        }
        else{
            sum=a+b;
            a=b;
            b=sum;
            cout<<sum<<" ";
        }
        
    }
    cout<<endl;
    return 0;
}