#include<iostream>
using namespace std;
int main(){
   int l=6;
   for(int i=1; i<=l; i++){
    for(int j=1; j<=i; j++){
        cout<<(j*5)<<" ";
    }
    cout<<endl;
   }
    return 0;
}