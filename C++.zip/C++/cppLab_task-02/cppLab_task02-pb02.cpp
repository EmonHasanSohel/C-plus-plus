#include<iostream>
using namespace std;
int main(){
    int num,sum=0;
    float avg;
    for(int i=0; i<5; i++){
    cout<<"Enter a number:";
    cin>>num;
    sum=sum+num;
    avg=sum/5;
    }
    cout<<"Average:"<<avg<<endl;
    
    return 0;
}