#include <iostream>
using namespace std;
int main() {
    int i=0;
    while(i<4){
        int num;
        cout<<"Enter a number:";
        cin>>num;
        if(num%2==0){
            cout<<num<<" is an even number"<<endl;

        }
        else{
            cout<<num<<" is an odd number"<<endl;

        }

    i++;
    }
}