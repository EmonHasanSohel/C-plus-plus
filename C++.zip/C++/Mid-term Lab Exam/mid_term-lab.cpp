#include<iostream>
using namespace std;
int main (){
    int id[6];
    float cgpa[6];
    for (int i=0; i<6; i++){
        cout<<"Enter your ID:";
        cin>>id[i];

        cout<<"Enter your cgpa:";
        cin>>cgpa[i];

    if (cgpa[i]<2.50){
        cout<<"The student is a probationary student."<<endl;
        }
        else if (cgpa[i]>2.49 && cgpa[i]<3.85){
            cout<<"The student is a regular student."<<endl;
        }
        else if (cgpa[i]>3.84){
            cout<<"The student is a scholarship student."<<endl;
        }
    }

return 0;
}