#include<iostream>
#include<string>
using namespace std;
struct Employee {
    string EmployeeName;
    string EmployeeID;
    float EmployeeSalary;
    int JoiningYear;

    void SetEmployeeInfo(string name,string id,float sal,int year){
        EmployeeName=name;
        EmployeeID=id;
        EmployeeSalary=sal;
        JoiningYear=year;
    }

    float SetBonus(){
        float bonus=0.0;

        if(EmployeeSalary>25000 && JoiningYear<2016){
            bonus=EmployeeSalary*0.3;
        }
        else if(EmployeeSalary>20000 && JoiningYear<2018){
            bonus=EmployeeSalary*0.2;
        } 
        else{
            bonus=EmployeeSalary*0.05;
        }
        return bonus;
    }

    void DisplayInfo(){
        cout<<"Employee Name:"<<EmployeeName<<endl;
        cout <<"Employee ID:"<<EmployeeID<<endl;
        cout<<"Employee Salary:"<<EmployeeSalary<<endl;
        cout<<"Joining Year:"<<JoiningYear<<endl;
        
        float bonus=SetBonus();
        if(bonus>0.0){
            cout<<"Bonus:"<<bonus<<endl;
            cout <<"Total Salary with Bonus:"<<EmployeeSalary+bonus<<endl;
        } 
        else{
            cout<<"No Bonus applicable!"<<endl;
        }
    }
};
int main(){
    Employee emp;
    emp.SetEmployeeInfo("MD. EMON HASAN SOHEL", "23-53171-3", 25000.0, 2020);
    emp.DisplayInfo();
    return 0;
}