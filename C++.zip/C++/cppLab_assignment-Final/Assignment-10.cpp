#include<iostream>
#include<string>
using namespace std;
class Car {
protected:
    string CarName;
    int CarID;
    string CarColor;
    float Price;

public:
    Car(string name,int id,string color,float price)
        :CarName(name),CarID(id),CarColor(color),Price(price){}
        void DisplayCarInfo(){
        cout<<"Car Name:"<<CarName<<endl;
        cout<<"Car ID:"<<CarID<<endl;
        cout<<"Car Color:"<<CarColor<<endl;
        cout<<"Car Price:$"<<Price<<endl;
        }
};

class TeslaAutopilot:public Car{
private:
    string CarType;
    float TaxPercentage;
public:
    TeslaAutopilot(string name, int id, string color, float price, string carType, float tax)
        : Car(name, id, color, price), CarType(carType), TaxPercentage(tax){}

    void DisplayTeslaInfo(){
        DisplayCarInfo();
        cout<<"Car Type:"<< CarType <<endl;
        cout<<"Tax Percentage:"<<TaxPercentage<<"%"<<endl;
    }
    float FinalPrice(){
        float finalPrice=Price-(Price * (TaxPercentage/100.0f));
        return finalPrice;
    }
};
int main() {
    Car car("Model T", 12345, "Black", 67000.0f);
    TeslaAutopilot tesla("Model 2", 56789, "Black", 70000.0f, "Autonomous", 20.0f);

    cout<<"Car Information:"<<endl;
    car.DisplayCarInfo();
    cout<<endl;

    cout<< "Tesla Information:"<<endl;
    tesla.DisplayTeslaInfo();
    cout<<"Final Price after deduction:$"<<tesla.FinalPrice()<<endl;
    return 0;
}