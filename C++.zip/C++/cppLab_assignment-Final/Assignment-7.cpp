#include<iostream>
using namespace std;
bool isLeapYear(int year) {
    return( (year%4==0 && year%100!=0) || (year%400==0) );
}
int main() {
    const int row=3;
    const int colum=3;
    int years[row][colum];

    cout<<"Enter 9 years:"<<endl;
    for(int i=0; i<row; ++i){
        for(int j=0; j<colum; ++j){
            cin>>years[i][j];
        }

    }
    cout<<endl;
    cout<<"The Inputted Years:"<<endl;
    for(int i=0; i<row; ++i){
        for(int j=0; j<colum; ++j){
            cout<<years[i][j]<<" ";
        }
    cout<<endl;
    }
    int mostRecent=years[0][0];
    int oldest=years[0][0];

    for(int i=0; i<row; ++i){
        for(int j=0; j<colum; ++j){
            if(years[i][j]>mostRecent){
                mostRecent=years[i][j];
            }
            if(years[i][j]<oldest){
                oldest=years[i][j];
            }
        }
    }
    cout<<"Most recent year:"<<mostRecent<<endl;
    cout <<"Oldest year:"<<oldest<<endl;
    cout<<"Leap years in the Input:"<<endl;
    for(int i=0; i<row; ++i){
        for(int j=0; j<colum; ++j){
            if (isLeapYear(years[i][j])){
                cout<<years[i][j]<< " ";
            }
        }
    }
    cout<<endl;
    return 0;
}