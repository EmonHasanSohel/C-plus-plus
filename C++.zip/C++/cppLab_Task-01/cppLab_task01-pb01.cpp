#include<iostream>
using namespace std;
int main(){
    float num1,num2,num3,num4,num5,sum;
    int avg;
    cout<<"Enter  five float variables: "<<endl;
    cin>>num1>>num2>>num3>>num4>>num5;
    sum=num1+num2+num3+num4+num5;
    avg=(sum/5);
    cout<<"Sumation:"<<sum<<endl;
    cout<<"Average:"<<avg<<endl;
    
    if(avg%2==0){
        cout<<"The average is even number"<<endl;
    }
    else{
        cout<<"The average is odd number"<<endl;
    }
    return 0;
}