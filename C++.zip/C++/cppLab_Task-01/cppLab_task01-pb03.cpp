#include<iostream>
using namespace std;
int main(){
    float num;
    cout<<"Enter a number:";
    cin>>num;
    if(num/(int) num==1){
        cout<<num<<" is an integer number"<<endl;
    }
    else{
         cout<<num<<" is a float number"<<endl;
    }
    return 0;

}