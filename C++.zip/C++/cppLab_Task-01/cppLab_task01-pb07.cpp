#include<iostream>
using namespace std;
int main(){
    char c;
    cout<<"Enter a character:";
    cin>>c;
    if(c=='m' || c=='M'){
        cout<<"Male"<<endl;
    }
    else if(c=='f' || c=='F'){
        cout<<"Female"<<endl;
    }
    else{
        cout<<"Undefined"<<endl;
    }
    return 0;
}
