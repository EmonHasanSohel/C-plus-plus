#include<iostream>
using namespace std;
int main(){
    int year;
    cout<<"Enter a year:";
    cin>>year;
    if(year>=1800 && year<=2023){
         if ((year%4==0 && year%100!=0) || (year%400==0)){
            cout<<year<<" is a leap yaer"<<endl;
        }
        else{
            cout<<year<<" is not a leap year"<<endl;
        }
    }
    else{
        cout<<"Invalid"<<endl;
    }
    return 0;
}