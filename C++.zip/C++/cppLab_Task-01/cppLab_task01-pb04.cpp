#include<iostream>
using namespace std;
int main(){
    int z,result;
    cout<<"Enter a variable:";
    cin>>z;
    result=((z*z*z*z*z)+(z*z*z*z*z*z*z)+(z*z*z*z*z*z*z*z*z)+(z*z*z*z)-((z*z*z)*(z*z)));
    cout<<"The result is:"<<result<<endl;
    return 0;
}
