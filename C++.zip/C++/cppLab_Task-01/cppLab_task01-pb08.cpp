#include<iostream>
using namespace std;
int main(){
    int p;
    float amount;
    cout<<"The charge for one page photocopy is 2.35 TAKA"<<endl;
    cout<<"How many pages do you want to photocopy?"<<endl;
    cin>>p;
    amount=(2.35*p);
    cout<<"Cost is:"<<amount<<endl;
    if(amount>100){
        cout<<"You have got 4% discount!!"<<endl;
        cout<<"After discount your total cost is:"<<(amount-(amount*0.04))<<endl;
    }
    else{
        cout<<"Sorry your cost is less than 100,So you do not get any discount"<<endl;
    }
    return 0;
}
