#include<iostream>
using namespace std;
int main(){
    float a,b,area;
    cout<<"Enter the base:";
    cin>>a;
    cout<<"Enter the height:";
    cin>>b;
    area=(0.5*b*a);
    cout<<"The area of the triangle is:"<<area<<endl;
    if((int)area%2==0){
        cout<<"The area is even number"<<endl;
    }
    else{
      cout<<"The area is odd  number"<<endl;
    }
    return 0;
}