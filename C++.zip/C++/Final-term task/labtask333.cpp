#include<iostream>
using namespace std;
void callbyvalue (int a){
    a=a+10;
    cout<<"Call by value:"<<a<<endl;
}
void callbyreference(int &b){
    b=b+20;
    cout<<"Call by value:"<<b<<endl;
}
int main (){
    int value=30;
    callbyvalue(value);
    cout<<"After call by value:"<<value<<endl;
 
    int reference1=40;
    callbyreference(reference1);
    cout <<"After reference:"<<reference1<<endl;
 return 0;
}