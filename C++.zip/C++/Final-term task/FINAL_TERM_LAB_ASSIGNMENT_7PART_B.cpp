#include <iostream>
 using namespace std;
 int main(){
 cout<<"Enter the years of array";
 int arr[3][3];
 for(int row=0;row<3;row++){
    for(int col=0;col<3;col++){
        cin>>arr[row][col];
    }
 }
cout<<endl;
cout<<"The array is:"<<endl;
 for(int row=0;row<3;row++){
    for(int col=0;col<3;col++){
     cout<<arr[row][col]<<" ";
    }
    cout<<endl;
 }

  int max=arr[0][0];
for(int col=0;col<3;col++){
for(int row=0;row<3;row++){
            if(arr[row][col]>max){
                max=arr[row][col];
            }

}

}
cout<<endl;
     cout<<"recent year"<<max<<endl;



  int min=arr[0][0];
for(int col=0;col<3;col++){
for(int row=0;row<3;row++){
            if(arr[row][col]<min){
                min=arr[row][col];
            }

}

}
cout<<endl;
     cout<<"oldest year"<<min<<endl;

cout<<"is a leap year"<<" "<<endl;
 for(int row=0;row<3;row++){
    for(int col=0;col<3;col++){
     if (arr[row][col]%400==0||arr[row][col]%4==0&&arr[row][col]%100!=0){
cout<<arr[row][col]<<" ";
     }
    }

 }
 }
