# include <iostream>
using namespace std;
struct Employee {
 string EmployeeName;
    string EmployeeID;
    float Employeesalary;
    int Year;

 set_EmployeeInfo(string name,string id,float sal,int year ){


    EmployeeName=name;
    EmployeeID=id;
    Employeesalary=sal;
    Year=year;

}
void set_bonus(){
float bonus;

if(Employeesalary>25000&&Year<2016){
   bonus=Employeesalary*.3;
   cout<<"Employee bonus:"<<bonus<<endl;
}
else if(Employeesalary>20000&&Year<2018){
 bonus=Employeesalary*.2;
   cout<<"Employee bonus:"<<bonus<<endl;
}
else{
     float  bonus=Employeesalary*.05;
   cout<<"Employee bonus:"<<bonus<<endl;
}
Employeesalary+=bonus;
cout<<"After bonus salary is :"<<Employeesalary<<endl;

}
void DisplayInfo(){
cout<<EmployeeName<<endl;
cout<<EmployeeID<<endl;
cout<< Employeesalary<<endl;
cout<<Year<<endl;

}

};
int main(){
Employee E;

E.set_EmployeeInfo("Tamanna Billah","2345_567",234567,2015);
E.DisplayInfo();
E.set_bonus();


}
