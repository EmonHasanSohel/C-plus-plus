#include <iostream>
using namespace std;
double balance=0.0;

void Deposit(){
    double amount;
    cout<<"Enter deposit amount:";
    cin>>amount;

    if(amount>0){
        balance += amount;
        cout<<"Deposited $:"<<amount <<endl;
        cout<<"New balance:"<<balance<<endl;
    } else {
       cout<<"Invalid deposit amount."<<endl;
    }
}

void Withdraw() {
    double amount;
    cout <<"Enter withdrawal amount:";
    cin >> amount;

    if (amount > 0 && amount <= balance) {
        balance-=amount;
        cout <<"Withdrawn $:"<<amount<<endl;
        cout<<"New balance:"<<balance<<endl;
    } else {
        cout <<"Invalid withdrawal amount or insufficient funds."<<endl;
    }
}

void CheckBalance(){
    cout <<"Current balance:"<< balance<<endl;
}

int main() {
    CheckBalance();

    
    Deposit();
    CheckBalance();

    
    Withdraw();
    CheckBalance();

    return 0;
}