#include <iostream>
#include <string>

using namespace std;

class Car {
protected:
    string CarName;
   string CarID;
    string CarColor;
    double Price;

public:
   void car(string name, string id, string color, double price){
       CarName=name;
         CarID=id;
         CarColor=color;
         Price=price;
   }
    void DisplayCarInfo() {
        cout << "Car Name: " << CarName << endl;
        cout << "Car ID: " << CarID << endl;
        cout << "Car Color: " << CarColor << endl;
        cout << "Car Price: $" << Price << endl;
    }
};

class TeslaAutopilot : public Car {
private:
    string CarType;
    float TaxPercentage;

public:
    Teslaautopilot(string name, string id, string color, float price, string type, float tax){
     CarName=name;
     CarID=id;
    CarColor=color;
     Price=price;
     CarType=type;
     TaxPercentage=tax;
    }


    void DisplayTeslaInfo() {

        cout << "Car Type: " << CarType << endl;
        cout << "Tax Percentage: " << TaxPercentage << "%" << endl;
    }

   double FinalPrice() {
      return Price - (Price * TaxPercentage / 100);

    }
};

int main() {
TeslaAutopilot C1;

C1.car("TOYOTA","23456","BLUE",30000);
C1.Teslaautopilot("MODEL S","2356","RED",90000,"AUTONOMUS",5);
 C1.DisplayCarInfo();
  C1. DisplayTeslaInfo();
  C1.FinalPrice();
    return 0;
}
