#include <iostream>
using namespace std;
int main() {
    int arr[4][5];
    cout<<"Enter elements of the array:"<<endl;
    for(int i=0; i<4; i++) {
        for(int j=0; j<5; j++){
          cin>>arr[i][j];
        }
    }
    cout<<endl;

    cout <<"The Inputted elements:"<<endl;
    for(int i=0; i<4; i++) {
        for(int j=0; j<5; j++){
            cout << arr[i][j] <<" ";
        }
        cout<<endl;
    }
    
    int max=arr[0][0];
    for(int i=0; i<5; i++){
        if(arr[0][i]>max){
            max=arr[0][i];
        }
    }
    cout<<endl;
    cout<<"Maximum number from row-1:"<<max<<endl;
    
    int min=arr[1][0];
    for(int i=0; i<5; i++){
        if(arr[1][i]<min){
            min=arr[1][i];
        }
    }
    
    cout <<"Minimum number from row-2:"<<min<<endl;

    cout << "Even numbers from row-3:";
    for(int i=0; i<5; i++) {
        if(arr[2][i]%2==0) {
            cout<<arr[2][i]<<" ";
        }
    }
    cout<<endl;
    
    cout<<"Prime numbers from row-4:";
    for(int i=0; i<5; i++){
        int num=arr[3][i];
        bool prime=true;
 
        if(num<=1){
            prime=false;
        }
        else {
            for(int j=2; j*j<=num; j++){
                if(num%j==0){
                    prime=false;
                    break;
                }
            }
        }
        if(prime){
            cout<<num<<" ";
        }
    }
    cout<<endl;
}