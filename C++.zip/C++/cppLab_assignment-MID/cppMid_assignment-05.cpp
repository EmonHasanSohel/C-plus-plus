#include <iostream>
using namespace std;
int main(){
    string str,str1;
    cout<<"Enter:";
    cin>>str;

    for(int i=str.size()-1;  i>=0;  i--){
        str1+=str[i];
    }

    cout<<"The reversed form of the string is:"<<str1<< endl;

    if(str==str1){
        cout << "It is a palindrome"<<endl;
    }
    
    else{
        cout << "It is not a Palindrome"<<endl;
    }

 return 0;
}