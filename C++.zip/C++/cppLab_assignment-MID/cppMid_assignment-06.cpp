#include<iostream>
using namespace std;
int main(){
    int a,b,s;
    float y=0,z=0,p,q;
    cout<<"Enter the number of matches:";
    cin>>a;
    cout<<"Goals scored by Lionel Messi:";
    
    for(int i=0; i<a; i++){
        cin>>b;
        y=y+b;
    }
    
    p=float(y/a);
    cout<<"Goals scored by Neymar da Silva Santos Junior:";
    
    for(int j=0;j<a;j++){
        cin>>s;
        z=z+s;
    }
    
    q=float(z/a);
    cout<<"Average goal scored by Lionel Messi is:"<<p<<endl;
    cout<<"Average goal scored by Neymar da Silva Santos Junior is:"<<q<<endl;
    
    if(p>q){
        cout<<"Lionel Messi is better"<<endl;
    }
    else if(p==q){
        cout<<"Equal"<<endl;
    }
    else{
        cout<<"Neymar da Silva Santos Junior is better"<<endl;
    }
return 0;
}