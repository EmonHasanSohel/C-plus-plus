#include<iostream>
using namespace std;
int main(){
    int p;
    float x,y,total_cost;
    char q;
    cout<<"Which type of gold do you want to purchase?"<<endl;
    cout<<"Press 1 for 22-Karat Gold"<<endl<<"Press 2 for 24-Karat Gold"<<endl;
    cin>>p;
    
    switch(p){
        case 1:
        cout<<"Input the quantity(gram) of gold:";
        cin>>p;
        cout<<"Price of 1 gram of 22-karat gold is 6529.4 Taka"<<endl;
        total_cost=(x*6529.4);
        cout<<"Your total cost is:"<<total_cost<<"BDT"<<endl;
        break;
        case 2:
        cout<<"Input the quantity(gram) of gold:";
        cin>>y;
        cout<<"Price of 1 gram of 24-karat gold is 7126.6 Taka"<<endl;
        total_cost=(y*7126.6);
        cout<<"Your total cost is:"<<total_cost<<"BDT"<<endl;
        break;
    }

    cout<<"Do you want to convert the money in US Dollar? Press Y for yes and N for no."<<endl;
    cin>>q;
    switch(q){
        case 'Y':
        cout<<"Total cost:$"<<(total_cost/110.24)<<endl;
        break;
        case 'N':
        cout<<"Thank you.";
        break;
    }

    return 0;
}