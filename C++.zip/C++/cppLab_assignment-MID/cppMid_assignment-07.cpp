#include<iostream>
using namespace std;
int main(){
    string player_name;
    int run;
    int sum=0;
    float avg;
    float previous;
    cout<<"Enter your Favourite Cricket player name:";
    cin>>player_name;
    cout<<"Enter the number of runs made by "<<player_name<<" in the last 4 ODI matches."<<endl;
    
    for (int i=0; i<4; i++){
        cin>>run;
        sum=sum+run;
    }
    
    avg=sum/4;
    cout<<"Average runs by "<<player_name<<" in the last 4 ODI matches: "<<avg<<endl;
    cout<<"Enter the average runs made by the player in 2022."<<endl;
    cin>>previous;
    if(avg>previous){
        cout<<"The performance of "<<player_name<<" is improving."<<endl;
    }
    else{
        cout<<"The performance of "<<player_name<<" is deteriorating."<<endl;
    }
return 0;
}