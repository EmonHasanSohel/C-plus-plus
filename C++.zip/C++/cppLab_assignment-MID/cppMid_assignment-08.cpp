#include<iostream>
using namespace std;
int main(){
    int a,b,i,y;
    cout<<"Enter the starting range:";
    cin>>a;
    cout<<"Enter the ending range:";
    cin>>b;
    int Size=(b-a)+1;
    int even[Size];
    cout<<"Element of even numbers:";
    for(int num=a;num<=b;num++){
        if(num%2==0){
            even[num]=num;
            cout<<even[num]<<" ";
        }
    }
    cout<<endl;
    cout<<"Element of the odd numbers:";
    int odd[Size];
    for(int numy=a; numy<=b; numy++){
        if(numy%2!=0){
            odd[numy]=numy;
            cout<<odd[numy]<<" ";
        }
    }
    cout<<endl;
    cout<<"Element of the prime numbers:";
    int prime[Size];
    int numx;
    
    for(numx=a; numx<=b; numx++){
        for(i=2;i<numx;i++){
            if(numx%i==0){
                break;
            }
        }
        if(i==numx){
            prime[numx]=numx;
            cout<<prime[numx]<<" ";
        }
    }
    cout<<endl;
    return 0;
}