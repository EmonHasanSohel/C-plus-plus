#include<iostream>
using namespace std;
int main() {
    float a;
    float b;
    float c;
    cout<<"Enter your score in Physics:";
    cin>>a;
    cout<<"Enter your score in Mathematics:";
    cin>>b;
    cout<<"Enter your score in Chemistry:";
    cin>>c;
    
    cout<<"Your grade in Physics is:";
    if (a<=90 && a>=80){
        cout<<"A+"<<endl;
    }
    else if (a>=70 && a<=79.99){
        cout<<"A"<<endl;
    }
    else if (a>=60 && a<=60.99){
        cout<<"B+"<<endl;
    }
    else if (a>=50 && a<=59.99){
        cout<<"B"<<endl;
    }
    else if (a<50){
        cout<<"F"<<endl;
    }
    

    cout<<"Your grade in Mathematics is:";
    if (c<=90 && c>=80){
        cout<<"A+"<<endl;
    }
    else if (c>=70 && c<=79.99){
        cout<<"A"<<endl;
    }
    else if (c>=60 && c<=60.99){
        cout<<"B+"<<endl;
    }
    else if (c>=50 && c<=59.99){
        cout<<"B"<<endl;
    }
    else if (c<50){
        cout<<"F"<<endl;
    }


    cout<<"Your grade in Chemistry is:";
    if (c<=90 && c>=80){
        cout<<"A+"<<endl;
    }
    else if (c>=70 && c<=79.99){
        cout<<"A"<<endl;
    }
    else if (c>=60 && c<=60.99){
        cout<<"B+"<<endl;
    }
    else if (c>=50 && c<=59.99){
        cout<<"B"<<endl;
    }
    else if (c<50){
        cout<<"F"<<endl;
    }
    
    
return 0;
}